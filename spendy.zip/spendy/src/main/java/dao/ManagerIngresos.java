package dao;

import models.Ingreso;
import java.util.*;
import org.json.*;

public class ManagerIngresos {
    private static final List<Ingreso> ingresos = new ArrayList<>();
    private static int seqId = 1;

    public static Ingreso crearIngreso(JSONObject body) {
        Ingreso i = new Ingreso(
            seqId++,
            body.getInt("usuarioId"),
            body.getString("fecha"),
            body.getDouble("importe"),
            body.getString("descripcion"),
            body.getString("fuente")
        );
        ingresos.add(i);
        return i;
    }

    public static List<Ingreso> obtenerIngresos() {
        return new ArrayList<>(ingresos);
    }
}