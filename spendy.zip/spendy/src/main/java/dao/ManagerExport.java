package dao;

import java.io.*;
import javax.servlet.http.HttpServletResponse;

public class ManagerExport {
    public static void exportarPDF(HttpServletResponse response) throws IOException {
        // TODO: implementar generación de PDF y escritura en el output stream
        response.setContentType("application/pdf");
        // response.getOutputStream()...
    }
}
