package dao;

import models.Configuracion;
import java.util.*;
import org.json.*;

public class ManagerConfiguracion {
    private static final Map<Integer, Configuracion> configs = new HashMap<>();

    public static Configuracion actualizarConfiguracion(JSONObject body) {
        int usuarioId = body.getInt("usuarioId");
        String tema = body.getString("tema");
        Configuracion c = new Configuracion(usuarioId, tema);
        configs.put(usuarioId, c);
        return c;
    }
}