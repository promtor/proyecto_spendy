package dao;

import models.Usuario;
import java.util.*;

public class ManagerUsuarios {
    private static final Map<Integer, Usuario> usuarios = new HashMap<>();
    private static int seqId = 1;

    /**
     * Crea un usuario y lo almacena en memoria.
     */
    public static Usuario crearUsuario(String nombre, String correo, String password) {
        Usuario u = new Usuario(seqId++, nombre, correo, password);
        usuarios.put(u.getId(), u);
        return u;
    }

    /**
     * Valida credenciales y devuelve un token si es correcto.
     */
    public static String login(String correo, String password) {
        for (Usuario u : usuarios.values()) {
            if (u.getCorreo().equals(correo) && u.getPassword().equals(password)) {
                // Generar token (dummy UUID)
                return UUID.randomUUID().toString();
            }
        }
        return null; // o lanzar excepción
    }
}
