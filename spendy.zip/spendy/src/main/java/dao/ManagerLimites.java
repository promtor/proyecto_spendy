package dao;

import models.Limite;
import java.util.*;
import org.json.*;

public class ManagerLimites {
    private static final Map<Integer, Limite> limites = new HashMap<>();

    public static Limite establecerLimite(int usuarioId, double valor) {
        Limite l = new Limite(usuarioId, valor);
        limites.put(usuarioId, l);
        return l;
    }

    public static List<Limite> obtenerLimites() {
        return new ArrayList<>(limites.values());
    }
}
