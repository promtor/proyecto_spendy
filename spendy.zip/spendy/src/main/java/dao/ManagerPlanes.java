package dao;

import java.util.*;
import org.json.*;

public class ManagerPlanes {
    public static JSONArray obtenerPlanes() {
        // TODO: generar sugerencias de ahorro en base a ingresos/gastos
        return new JSONArray();
    }
}

