package dao;

import models.Gasto;
import java.util.*;
import org.json.*;

public class ManagerGastos {
    private static final List<Gasto> gastos = new ArrayList<>();
    private static int seqId = 1;

    public static Gasto crearGasto(JSONObject body) {
        Gasto g = new Gasto(
            seqId++,
            body.getInt("usuarioId"),
            body.getString("fecha"),
            body.getDouble("importe"),
            body.getInt("categoriaId"),
            body.getString("descripcion"),
            body.optDouble("latitud", 0),
            body.optDouble("longitud", 0)
        );
        gastos.add(g);
        return g;
    }

    public static List<Gasto> obtenerGastos() {
        return new ArrayList<>(gastos);
    }

    public static List<Gasto> buscarGastos(String q) {
        List<Gasto> res = new ArrayList<>();
        for (Gasto g : gastos) {
            if (g.getDescripcion().toLowerCase().contains(q.toLowerCase())) {
                res.add(g);
            }
        }
        return res;
    }

    public static List<Gasto> filtrarGastos(JSONObject filtros) {
        // TODO: implementar filtrado por fechas, rangos e id de categoría
        return obtenerGastos();
    }

    public static JSONObject datosGraficoMensual() {
        // TODO: agrupar por mes y retornar {"mes": total, ...}
        return new JSONObject();
    }

    public static JSONArray obtenerUbicaciones() {
        JSONArray arr = new JSONArray();
        for (Gasto g : gastos) {
            JSONObject o = new JSONObject();
            o.put("latitud", g.getLatitud());
            o.put("longitud", g.getLongitud());
            arr.put(o);
        }
        return arr;
    }
}