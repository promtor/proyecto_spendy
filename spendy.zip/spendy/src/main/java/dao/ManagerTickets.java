package dao;

import models.Ticket;
import java.util.*;
import org.json.*;

public class ManagerTickets {
    private static final List<Ticket> tickets = new ArrayList<>();
    private static int seqId = 1;

    public static Ticket crearTicket(JSONObject body) {
        Ticket t = new Ticket(
            seqId++,
            body.getInt("gastoId"),
            body.getString("imagenPath"),
            body.getString("textoOCR")
        );
        tickets.add(t);
        return t;
    }

    public static List<Ticket> obtenerTickets() {
        return new ArrayList<>(tickets);
    }

    public static Ticket actualizarTicket(int id, String nuevoOCR) {
        for (Ticket t : tickets) {
            if (t.getId() == id) {
                t.setTextoOCR(nuevoOCR);
                return t;
            }
        }
        return null;
    }

    public static boolean borrarTicket(int id) {
        return tickets.removeIf(t -> t.getId() == id);
    }
}
