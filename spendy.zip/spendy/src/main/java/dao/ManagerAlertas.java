package dao;

import models.Alerta;
import java.util.*;

public class ManagerAlertas {
    public static List<Alerta> obtenerAlertas() {
        // TODO: generar alertas basadas en límites y gastos actuales
        return new ArrayList<>();
    }
}
