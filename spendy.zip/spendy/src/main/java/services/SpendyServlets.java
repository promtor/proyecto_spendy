package services;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

// Manager and model classes (to be implemented similarly to the functional project)
import dao.ManagerUsuarios;
import dao.ManagerGastos;
import dao.ManagerIngresos;
import dao.ManagerTickets;
import dao.ManagerPlanes;
import dao.ManagerLimites;
import dao.ManagerAlertas;
import dao.ManagerConfiguracion;
import dao.ManagerExport;
import models.Usuario;
import models.Gasto;
import models.Ingreso;
import models.Ticket;

// 1. Registro de Usuario
@WebServlet("/api/usuarios")
public class RegistroUsuarioServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject body = new JSONObject(request.getReader().lines().reduce("", String::concat));
        String nombre = body.getString("nombre");
        String correo = body.getString("correo");
        String password = body.getString("password");
        Usuario user = ManagerUsuarios.crearUsuario(nombre, correo, password);
        response.setContentType("application/json");
        response.getWriter().write(new JSONObject(user).toString());
    }
}

// 2. Login
@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject body = new JSONObject(request.getReader().lines().reduce("", String::concat));
        String correo = body.getString("correo");
        String password = body.getString("password");
        String token = ManagerUsuarios.login(correo, password);
        response.setContentType("application/json");
        response.getWriter().write(new JSONObject().put("token", token).toString());
    }
}

// 3. Gastos: registro y listado
@WebServlet(urlPatterns = {"/api/gastos"})
public class GastoServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject body = new JSONObject(request.getReader().lines().reduce("", String::concat));
        Gasto g = ManagerGastos.crearGasto(body);
        response.setContentType("application/json");
        response.getWriter().write(new JSONObject(g).toString());
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Gasto> lista = ManagerGastos.obtenerGastos();
        JSONArray arr = new JSONArray(lista);
        response.setContentType("application/json");
        response.getWriter().write(new JSONObject().put("gastos", arr).toString());
    }
}

// 4. Buscar Gastos
@WebServlet("/api/gastos/buscar")
public class BuscarGastosServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String q = request.getParameter("q");
        List<Gasto> resultados = ManagerGastos.buscarGastos(q);
        JSONArray arr = new JSONArray(resultados);
        response.setContentType("application/json");
        response.getWriter().write(new JSONObject().put("resultados", arr).toString());
    }
}

// 5. Filtrar Gastos
@WebServlet("/api/gastos/filtro")
public class FiltrarGastosServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject filtros = new JSONObject();
        request.getParameterMap().forEach((k,v)-> filtros.put(k, v[0]));
        List<Gasto> filtrados = ManagerGastos.filtrarGastos(filtros);
        JSONArray arr = new JSONArray(filtrados);
        response.setContentType("application/json");
        response.getWriter().write(new JSONObject().put("gastos", arr).toString());
    }
}

// 6. Gráficos Mensuales
@WebServlet("/api/graficos")
public class GraficosServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject datos = ManagerGastos.datosGraficoMensual();
        response.setContentType("application/json");
        response.getWriter().write(datos.toString());
    }
}

// 7. Mapa de Gastos
@WebServlet("/api/mapa")
public class MapaServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONArray ubicaciones = ManagerGastos.obtenerUbicaciones();
        response.setContentType("application/json");
        response.getWriter().write(new JSONObject().put("mapa", ubicaciones).toString());
    }
}

// ... Continúa con servlets para ingresos, resumen, planes, tickets, exportar PDF, límites, alertas, configuración, compartir gastos, recuperación de contraseña etc. Sigue la misma estructura de abajo:
// @WebServlet("/api/ingresos")
// public class IngresoServlet extends HttpServlet { ... }

// @WebServlet("/api/resumen")
// public class ResumenServlet extends HttpServlet { ... }

// @WebServlet("/api/planes")
// public class PlanesServlet extends HttpServlet { ... }

// @WebServlet("/api/tickets")
// public class TicketsServlet extends HttpServlet { ... }

// @WebServlet("/api/export/pdf")
// public class ExportPdfServlet extends HttpServlet { ... }

// @WebServlet("/api/limites")
// public class LimitesServlet extends HttpServlet { ... }

// @WebServlet("/api/alertas")
// public class AlertasServlet extends HttpServlet { ... }

// @WebServlet("/api/configuracion")
// public class ConfiguracionServlet extends HttpServlet { ... }

// @WebServlet("/api/gastos/compartir")
// public class CompartirGastosServlet extends HttpServlet { ... }

// @WebServlet("/api/recuperar")
// public class RecuperarPasswordServlet extends HttpServlet { ... }
