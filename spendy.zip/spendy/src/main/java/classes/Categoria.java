package classes;

public interface Categoria {
    Long getId();

    void setId(Long id);

    Long getUsuarioId();

    void setUsuarioId(Long usuarioId);

    String getNombre();

    void setNombre(String nombre);
}
